import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import {
  Globe, Lock, Users, Crown, Settings, Camera,
  UserPlus, Copy, Trash2, Share2, Clock, CheckCircle2,
} from "lucide-react";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n/I18nProvider";
import { LOCALES, LOCALE_LABELS, type Locale } from "@/lib/i18n/translations";
import {
  createInvite, revokeInvite, inviteLink, useTesterInvites, useTesterSession,
  endTesterSession, formatRemaining,
} from "@/lib/testerAccess";

export const Route = createFileRoute("/_tabs/me")({
  component: ProfileScreen,
});

type Vis = "public" | "family" | "private";

function ProfileScreen() {
  const { t, locale, setLocale } = useI18n();
  const initialFields: { label: string; value: string; vis: Vis }[] = [
    { label: "Ethnie", value: "Akan", vis: "public" },
    { label: "Clan", value: "Asona", vis: "family" },
    { label: "Totem", value: "Le Corbeau", vis: "family" },
    { label: "Langue", value: "Twi · Français", vis: "public" },
    { label: "Titre", value: "—", vis: "private" },
    { label: "Religion", value: "Spiritualité Akan", vis: "family" },
    { label: "Initiations", value: "Bragoro (1996)", vis: "private" },
    { label: "Histoire orale", value: "Mon arrière-grand-père a fondé le village…", vis: "family" },
  ];
  const [fields, setFields] = useState(initialFields);
  const verifiedLabel = t<string>("tree.verified");
  const meta = t<string>("common.profileMeta", { year: "92", verifiedLabel });

  const cycle = (i: number) => {
    setFields((prev) =>
      prev.map((f, idx) =>
        idx === i
          ? {
              ...f,
              vis: f.vis === "public" ? "family" : f.vis === "family" ? "private" : "public",
            }
          : f,
      ),
    );
  };

  return (
    <div className="flex flex-col">
      <header className="relative bg-grain px-4 pb-6 pt-8">
        <div className="absolute right-4 top-5">
          <button className="flex h-10 w-10 items-center justify-center rounded-full bg-card ring-1 ring-border">
            <Settings className="h-4 w-4" />
          </button>
        </div>
        <div className="flex flex-col items-center text-center">
          <div className="relative">
            <div className="flex h-24 w-24 items-center justify-center rounded-full bg-primary text-primary-foreground ring-4 ring-card">
              <span className="font-display text-3xl font-semibold">K</span>
            </div>
            <button
              aria-label="Changer la photo"
              className="absolute -bottom-1 right-0 flex h-8 w-8 items-center justify-center rounded-full bg-accent text-accent-foreground ring-2 ring-background"
            >
              <Camera className="h-4 w-4" />
            </button>
          </div>
          <h1 className="mt-3 font-display text-2xl text-foreground">Kojo Mensah</h1>
          <p className="text-xs text-muted-foreground">{meta}</p>
        </div>
      </header>

      <section className="mx-3 -mt-4 rounded-3xl border border-border bg-card p-4 shadow-sm">
        <div className="mb-3 flex items-center gap-2">
          <Crown className="h-4 w-4 text-accent" />
          <h2 className="font-display text-base">{t("me.headOfFamily")}</h2>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-full bg-primary/10 font-display font-semibold text-primary">
            KM
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium">Kwame Mensah</p>
            <p className="text-xs text-muted-foreground">Père · Aîné de la lignée</p>
          </div>
          <button className="rounded-lg border border-border px-3 py-1.5 text-xs font-medium">{t("me.change")}</button>
        </div>
      </section>

      <section className="mx-3 mt-3 rounded-3xl border border-border bg-card p-4">
        <div className="mb-3 flex items-center gap-2">
          <Globe className="h-4 w-4 text-primary" />
          <h2 className="font-display text-base">{t("me.language")}</h2>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {LOCALES.map((l) => (
            <button
              key={l}
              onClick={() => setLocale(l)}
              className={`rounded-xl border px-2 py-2 text-xs font-medium transition ${
                locale === l
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border bg-background text-foreground"
              }`}
            >
              {LOCALE_LABELS[l as Locale]}
            </button>
          ))}
        </div>
      </section>

      <section className="mx-3 mt-3 rounded-3xl border border-border bg-card p-4">
        <h2 className="mb-2 font-display text-base">{t("me.culturalData")}</h2>
        <p className="mb-3 text-[11px] text-muted-foreground">{t("me.culturalHint")}</p>
        <ul className="divide-y divide-border">
          {fields.map((f, i) => (
            <li key={f.label} className="flex items-center gap-3 py-3">
              <div className="flex-1">
                <p className="text-[11px] uppercase tracking-wider text-muted-foreground">{f.label}</p>
                <p className="text-sm text-foreground">{f.value}</p>
              </div>
              <VisToggle vis={f.vis} onClick={() => cycle(i)} />
            </li>
          ))}
        </ul>
      </section>

      <section className="mx-3 mt-3 rounded-3xl border border-border bg-card p-4">
        <h2 className="mb-3 font-display text-base">{t("me.discoveryPrefs")}</h2>
        <Toggle label={t<string>("me.appearInSuggestions")} defaultOn />
        <Toggle label={t<string>("me.detectLinks")} defaultOn />
        <Toggle label={t<string>("me.receiveInvites")} />
      </section>

      <TesterInvitesSection />

      <div className="h-6" />
    </div>
  );
}

function TesterInvitesSection() {
  const invites = useTesterInvites();
  const session = useTesterSession();
  const [label, setLabel] = useState("");

  const handleCreate = () => {
    const inv = createInvite(label || undefined);
    setLabel("");
    toast.success("Invitation créée", {
      description: `Code ${inv.code} · valide 7 jours.`,
    });
  };

  const copy = async (code: string) => {
    const url = inviteLink(code);
    try {
      await navigator.clipboard.writeText(url);
      toast.success("Lien copié", { description: url });
    } catch {
      toast.error("Impossible de copier");
    }
  };

  const share = async (code: string) => {
    const url = inviteLink(code);
    const text = `Tu es invité·e à tester Baobab. Active ton accès ici : ${url}`;
    if (typeof navigator !== "undefined" && "share" in navigator) {
      try {
        await navigator.share({ title: "Invitation Baobab", text, url });
        return;
      } catch {
        /* user cancelled */
      }
    }
    copy(code);
  };

  return (
    <section className="mx-3 mt-3 rounded-3xl border border-border bg-card p-4">
      <div className="mb-3 flex items-center gap-2">
        <UserPlus className="h-4 w-4 text-primary" />
        <h2 className="font-display text-base">Inviter des testeurs</h2>
      </div>
      <p className="mb-3 text-[11px] text-muted-foreground">
        Génère un lien à usage limité. Tes testeurs y accèdent sans créer de compte —
        l'accès expire automatiquement après 7 jours.
      </p>

      {session && (
        <div className="mb-3 flex items-start gap-2 rounded-xl border border-primary/30 bg-primary/10 p-3 text-[12px]">
          <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
          <div className="flex-1">
            <p className="font-semibold text-foreground">
              Tu utilises Baobab en mode testeur ({session.alias})
            </p>
            <p className="text-foreground/80">
              {formatRemaining(session.expiresAt - Date.now())} · code {session.code}
            </p>
          </div>
          <button
            onClick={() => {
              endTesterSession();
              toast.success("Session testeur terminée");
            }}
            className="rounded-lg border border-border bg-card px-2 py-1 text-[11px]"
          >
            Quitter
          </button>
        </div>
      )}

      <div className="flex gap-2">
        <input
          value={label}
          onChange={(e) => setLabel(e.target.value)}
          placeholder="Nom du testeur (optionnel)"
          className="h-11 flex-1 rounded-xl border border-border bg-background px-3 text-sm outline-none focus:border-primary"
        />
        <button
          onClick={handleCreate}
          className="flex h-11 items-center gap-1.5 rounded-xl bg-primary px-3 text-sm font-semibold text-primary-foreground active:scale-[0.98]"
        >
          <UserPlus className="h-4 w-4" /> Créer
        </button>
      </div>

      {invites.length === 0 ? (
        <p className="mt-4 rounded-xl border border-dashed border-border p-3 text-center text-xs text-muted-foreground">
          Aucune invitation pour l'instant.
        </p>
      ) : (
        <ul className="mt-4 divide-y divide-border">
          {invites.map((inv) => {
            const remaining = inv.expiresAt - Date.now();
            const expired = remaining <= 0;
            const used = !!inv.redeemedAt;
            return (
              <li key={inv.code} className="flex items-center gap-3 py-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-sm font-semibold tracking-widest">
                      {inv.code}
                    </span>
                    <span
                      className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${
                        expired
                          ? "bg-muted text-muted-foreground"
                          : used
                            ? "bg-primary/10 text-primary"
                            : "bg-accent/20 text-accent-foreground"
                      }`}
                    >
                      {expired ? "Expiré" : used ? "Activé" : "En attente"}
                    </span>
                  </div>
                  <p className="truncate text-[11px] text-muted-foreground">
                    {inv.label}
                    {used && inv.redeemedBy ? ` · par ${inv.redeemedBy}` : ""}
                    {!expired && (
                      <>
                        {" · "}
                        <Clock className="-mt-0.5 inline h-3 w-3" />{" "}
                        {formatRemaining(remaining)}
                      </>
                    )}
                  </p>
                </div>
                <button
                  onClick={() => copy(inv.code)}
                  disabled={expired}
                  aria-label="Copier le lien"
                  className="flex h-9 w-9 items-center justify-center rounded-lg border border-border bg-background disabled:opacity-40"
                >
                  <Copy className="h-4 w-4" />
                </button>
                <button
                  onClick={() => share(inv.code)}
                  disabled={expired}
                  aria-label="Partager le lien"
                  className="flex h-9 w-9 items-center justify-center rounded-lg border border-border bg-background disabled:opacity-40"
                >
                  <Share2 className="h-4 w-4" />
                </button>
                <button
                  onClick={() => {
                    revokeInvite(inv.code);
                    toast.success("Invitation révoquée");
                  }}
                  aria-label="Révoquer"
                  className="flex h-9 w-9 items-center justify-center rounded-lg border border-border bg-background text-destructive"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}

function VisToggle({ vis, onClick }: { vis: Vis; onClick: () => void }) {
  const { t } = useI18n();
  const map = {
    public: { icon: Globe, label: t<string>("me.visPublic"), cls: "bg-primary/10 text-primary" },
    family: { icon: Users, label: t<string>("me.visFamily"), cls: "bg-accent/20 text-accent-foreground" },
    private: { icon: Lock, label: t<string>("me.visPrivate"), cls: "bg-muted text-muted-foreground" },
  } as const;
  const m = map[vis];
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-medium ${m.cls}`}
    >
      <m.icon className="h-3 w-3" />
      {m.label}
    </button>
  );
}

function Toggle({ label, defaultOn }: { label: string; defaultOn?: boolean }) {
  const [on, setOn] = useState(!!defaultOn);
  return (
    <button
      onClick={() => setOn(!on)}
      className="flex w-full items-center justify-between py-2.5 text-left"
    >
      <span className="text-sm">{label}</span>
      <span
        className={`relative h-6 w-10 rounded-full transition ${on ? "bg-primary" : "bg-muted"}`}
      >
        <span
          className={`absolute top-0.5 h-5 w-5 rounded-full bg-card shadow transition ${
            on ? "left-[18px]" : "left-0.5"
          }`}
        />
      </span>
    </button>
  );
}