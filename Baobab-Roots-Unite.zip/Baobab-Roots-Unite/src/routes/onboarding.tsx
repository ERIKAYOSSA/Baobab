import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import {
  Phone, ShieldCheck, IdCard, Users, Search, ChevronLeft, ChevronRight,
  Check, AlertTriangle, Send, Loader2, PartyPopper, Clock, X, Plus, Globe, Languages,
} from "lucide-react";
import { toast } from "sonner";
import { sendLinkRequest, useLinkRequest, statusLabel } from "@/lib/linkRequests";
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogAction,
} from "@/components/ui/alert-dialog";

export const Route = createFileRoute("/onboarding")({
  component: Onboarding,
});

const COUNTRIES = [
  "Afrique du Sud", "Algérie", "Allemagne", "Angola", "Bénin", "Belgique", "Botswana",
  "Burkina Faso", "Burundi", "Cameroun", "Canada", "Cap-Vert", "Centrafrique", "Comores",
  "Congo", "Côte d'Ivoire", "Djibouti", "Égypte", "Érythrée", "Espagne", "Eswatini",
  "États-Unis", "Éthiopie", "France", "Gabon", "Gambie", "Ghana", "Guinée",
  "Guinée-Bissau", "Guinée équatoriale", "Haïti", "Italie", "Jamaïque", "Kenya",
  "Lesotho", "Libéria", "Libye", "Madagascar", "Malawi", "Mali", "Maroc", "Maurice",
  "Mauritanie", "Mozambique", "Namibie", "Niger", "Nigéria", "Ouganda", "Portugal",
  "République démocratique du Congo", "Royaume-Uni", "Rwanda", "São Tomé-et-Príncipe",
  "Sénégal", "Seychelles", "Sierra Leone", "Somalie", "Soudan", "Soudan du Sud",
  "Suisse", "Tanzanie", "Tchad", "Togo", "Tunisie", "Zambie", "Zimbabwe",
];

const ETHNICITY_SUGGESTIONS = [
  "Akan", "Yoruba", "Igbo", "Bantou", "Wolof", "Peul", "Mandingue", "Zulu",
  "Amhara", "Swahili", "Bambara", "Hausa", "Kikuyu", "Baoulé", "Fon", "Massaï",
  "Soninké", "Sérère", "Dioula", "Mossi", "Toucouleur", "Lingala",
];

const LANGUAGE_SUGGESTIONS = [
  "Français", "Anglais", "Arabe", "Portugais", "Espagnol", "Wolof", "Bambara",
  "Lingala", "Swahili", "Yoruba", "Haoussa", "Peul", "Akan", "Zoulou", "Amharique",
  "Créole", "Kinyarwanda", "Soussou", "Dioula",
];

const SAMPLE_RELATIVES = [
  { id: "p1", n: "Kwame Mensah", c: "Akan · Abidjan", tree: 42 },
  { id: "p2", n: "Adjoa Mensah", c: "Akan · Kumasi", tree: 28 },
  { id: "p3", n: "Yaa Owusu", c: "Akan · Accra", tree: 17 },
  { id: "p4", n: "Kojo Boateng", c: "Akan · Lomé", tree: 9 },
];

function Onboarding() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [phone, setPhone] = useState("");
  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [dob, setDob] = useState("");
  const [gender, setGender] = useState<"f" | "m" | "x" | "">("");
  const [hasId, setHasId] = useState<null | boolean>(null);
  const [showIdAlert, setShowIdAlert] = useState(false);
  const [ethnicity, setEthnicity] = useState("");
  const [nationalities, setNationalities] = useState<string[]>([""]);
  const [countryOfOrigin, setCountryOfOrigin] = useState("");
  const [languages, setLanguages] = useState<string[]>([""]);
  const [knowsRelative, setKnowsRelative] = useState<null | boolean>(null);
  const [search, setSearch] = useState("");
  const [chosenRelative, setChosenRelative] = useState<string | null>(null);
  const [relation, setRelation] = useState<string>("");
  const [sending, setSending] = useState(false);
  const [requestId, setRequestId] = useState<string | null>(null);
  const liveRequest = useLinkRequest(requestId);

  const total = 5;
  const next = () => setStep((s) => Math.min(s + 1, total));
  const back = () => (step === 1 ? navigate({ to: "/" }) : setStep((s) => s - 1));

  const step5Ready =
    knowsRelative === false ||
    (knowsRelative === true && !!chosenRelative && !!relation);

  const finish = async () => {
    if (liveRequest && liveRequest.status !== "pending") {
      navigate({ to: "/tree" });
      return;
    }
    if (knowsRelative === true && chosenRelative && relation) {
      const target = SAMPLE_RELATIVES.find((p) => p.id === chosenRelative);
      if (!target) return;
      setSending(true);
      try {
        const req = await sendLinkRequest({
          targetId: target.id,
          targetName: target.n,
          relation,
        });
        setRequestId(req.id);
        toast.success("Demande envoyée", {
          description: `${target.n} doit confirmer le lien « ${relation} ». Tu verras le statut dans Notifications.`,
        });
      } catch {
        toast.error("Échec de l'envoi. Réessaie.");
        setSending(false);
        return;
      }
      setSending(false);
      return; // Stay on screen so user sees pending status; they can continue manually.
    } else {
      toast.success("Bienvenue sur Baobab", {
        description: "Commence par ajouter tes parents à ton arbre.",
      });
      navigate({ to: "/tree" });
    }
  };

  return (
    <div className="mx-auto flex min-h-dvh max-w-md flex-col bg-background">
      {/* Top bar */}
      <div className="flex items-center gap-3 px-4 pb-2 pt-5">
        <button onClick={back} className="flex h-9 w-9 items-center justify-center rounded-full bg-card ring-1 ring-border">
          <ChevronLeft className="h-4 w-4" />
        </button>
        <div className="flex-1">
          <div className="flex h-1.5 w-full overflow-hidden rounded-full bg-muted">
            <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${(step / total) * 100}%` }} />
          </div>
        </div>
        <span className="text-xs text-muted-foreground">{step}/{total}</span>
      </div>

      <div className="flex-1 px-5 pt-4">
        {step === 1 && (
          <Step icon={Phone} title="Ton numéro" subtitle="On t'envoie un code par SMS pour créer et te lier à ce compte.">
            <input
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+237 6 00 00 00 00"
              className="h-12 w-full rounded-2xl border border-border bg-card px-4 text-base outline-none focus:border-primary"
            />
            <div className="mt-3">
              <p className="mb-1 text-xs text-muted-foreground">Code reçu par SMS</p>
              <div className="flex justify-center gap-2">
                {[0, 1, 2, 3, 4].map((i) => (
                  <input
                    key={i}
                    maxLength={1}
                    value={code[i] ?? ""}
                    onChange={(e) => {
                      const v = e.target.value.replace(/\D/g, "").slice(0, 1);
                      setCode((c) => (c.substring(0, i) + v + c.substring(i + 1)).slice(0, 5));
                    }}
                    inputMode="numeric"
                    className="h-12 w-11 shrink-0 rounded-xl border border-border bg-card text-center text-lg font-semibold outline-none focus:border-primary"
                  />
                ))}
              </div>
            </div>
          </Step>
        )}

        {step === 2 && (
          <Step icon={ShieldCheck} title="Qui es-tu ?" subtitle="Ces infos restent privées par défaut.">
            <Field label="Nom complet">
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex. Kojo Mensah"
                className="h-12 w-full rounded-2xl border border-border bg-card px-4 outline-none focus:border-primary" />
            </Field>
            <Field label="Date de naissance">
              <input value={dob} onChange={(e) => setDob(e.target.value)} type="date"
                className="h-12 w-full rounded-2xl border border-border bg-card px-4 outline-none focus:border-primary" />
            </Field>
            <Field label="Genre">
              <div className="grid grid-cols-3 gap-2">
                {[
                  { v: "f", l: "Femme" }, { v: "m", l: "Homme" }, { v: "x", l: "Autre" },
                ].map((o) => (
                  <button key={o.v} onClick={() => setGender(o.v as never)}
                    className={`h-11 rounded-xl border text-sm font-medium ${gender === o.v ? "border-primary bg-primary/10 text-primary" : "border-border bg-card text-foreground"}`}>
                    {o.l}
                  </button>
                ))}
              </div>
            </Field>
          </Step>
        )}

        {step === 3 && (
          <Step icon={IdCard} title="Pièce d'identité" subtitle="Pour vérifier ton profil et débloquer toutes les fonctionnalités.">
            <button onClick={() => setHasId(true)}
              className={`flex w-full items-center gap-3 rounded-2xl border p-4 text-left ${hasId === true ? "border-primary bg-primary/5" : "border-border bg-card"}`}>
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary"><IdCard className="h-5 w-5" /></div>
              <div className="flex-1">
                <p className="font-medium">Téléverser ma pièce</p>
                <p className="text-xs text-muted-foreground">CNI, passeport, permis</p>
              </div>
              {hasId === true && <Check className="h-5 w-5 text-primary" />}
            </button>
            <button onClick={() => setShowIdAlert(true)}
              className={`mt-2 flex w-full items-center gap-3 rounded-2xl border p-4 text-left ${hasId === false ? "border-accent bg-accent/10" : "border-border bg-card"}`}>
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-muted text-muted-foreground">…</div>
              <div className="flex-1">
                <p className="font-medium">Plus tard</p>
                <p className="text-xs text-muted-foreground">Mode limité activé</p>
              </div>
            </button>
            {hasId === false && (
              <div className="mt-4 flex gap-2 rounded-2xl border border-accent/40 bg-accent/10 p-3 text-xs text-accent-foreground">
                <AlertTriangle className="h-4 w-4 shrink-0" />
                Mode limité activé. Vérifie ton identité plus tard pour débloquer toutes les fonctionnalités.
              </div>
            )}
            <AlertDialog open={showIdAlert} onOpenChange={setShowIdAlert}>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-accent-foreground" />
                    Mode limité
                  </AlertDialogTitle>
                  <AlertDialogDescription>
                    Vérifie ton identité pour débloquer toutes les fonctionnalités (proposer des liens, certifier des proches…).
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogAction
                    onClick={() => {
                      setHasId(false);
                      setShowIdAlert(false);
                      next();
                    }}
                  >
                    OK
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </Step>
        )}

        {step === 4 && (
          <Step icon={Globe} title="Identité culturelle" subtitle="Ces informations enrichissent ton arbre et t'aident à découvrir des liens.">
            <Field label="Nationalité (obligatoire)">
              <p className="mb-2 text-xs text-muted-foreground">Quelle est ta nationalité ?</p>
              {nationalities.map((nat, idx) => (
                <div key={idx} className="mb-2">
                  <CountryAutocomplete
                    value={nat}
                    onChange={(v) => {
                      const copy = [...nationalities];
                      copy[idx] = v;
                      setNationalities(copy);
                    }}
                    onRemove={idx > 0 ? () => setNationalities(nationalities.filter((_, i) => i !== idx)) : undefined}
                    placeholder="Tape les premières lettres…"
                  />
                </div>
              ))}
              {nationalities.length < 3 && (
                <button
                  onClick={() => setNationalities([...nationalities, ""])}
                  className="mt-1 flex items-center gap-1.5 rounded-full border border-dashed border-border bg-card px-3 py-1.5 text-xs font-medium text-muted-foreground hover:border-primary hover:text-primary"
                >
                  <Plus className="h-3.5 w-3.5" /> Ajouter une autre nationalité légale
                </button>
              )}
            </Field>

            <Field label="Pays d'origine (optionnel)">
              <p className="mb-2 text-xs text-muted-foreground">Quel est ton pays d'origine (si différent de ta nationalité) ?</p>
              <CountryAutocomplete
                value={countryOfOrigin}
                onChange={setCountryOfOrigin}
                placeholder="Tape les premières lettres…"
              />
              <p className="mt-1.5 text-[11px] text-muted-foreground/80">Par exemple : le pays de tes parents ou grands-parents.</p>
            </Field>

            <Field label="Origine / Ethnie (optionnel)">
              <p className="mb-2 text-xs text-muted-foreground">As-tu une ethnie, une origine, ou une communauté à laquelle tu t'identifies ?</p>
              <FreeAutocomplete
                value={ethnicity}
                onChange={setEthnicity}
                suggestions={ETHNICITY_SUGGESTIONS}
                placeholder="Ex. Baoulé, Fon, Massaï…"
              />
              <p className="mt-1.5 text-[11px] text-muted-foreground/80">Cette information t'aidera à découvrir des liens familiaux que tu ignores. Tu pourras la modifier plus tard.</p>
            </Field>

            <Field label="Langue(s) maternelle(s)">
              <p className="mb-2 text-xs text-muted-foreground">Quelle(s) langue(s) parles-tu ou parlait ta famille ?</p>
              {languages.map((lang, idx) => (
                <div key={idx} className="mb-2">
                  <FreeAutocomplete
                    value={lang}
                    onChange={(v) => {
                      const copy = [...languages];
                      copy[idx] = v;
                      setLanguages(copy);
                    }}
                    onRemove={idx > 0 ? () => setLanguages(languages.filter((_, i) => i !== idx)) : undefined}
                    suggestions={LANGUAGE_SUGGESTIONS}
                    placeholder="Ex. Wolof, Français, Lingala…"
                    icon={<Languages className="h-4 w-4 text-muted-foreground" />}
                  />
                </div>
              ))}
              {languages.length < 5 && (
                <button
                  onClick={() => setLanguages([...languages, ""])}
                  className="mt-1 flex items-center gap-1.5 rounded-full border border-dashed border-border bg-card px-3 py-1.5 text-xs font-medium text-muted-foreground hover:border-primary hover:text-primary"
                >
                  <Plus className="h-3.5 w-3.5" /> Ajouter une autre langue parlée
                </button>
              )}
            </Field>
          </Step>
        )}

        {step === 5 && (
          <Step icon={Search} title="Un proche déjà sur Baobab ?" subtitle="On va te connecter directement à son arbre.">
            <div className="grid grid-cols-2 gap-2">
              <button onClick={() => setKnowsRelative(true)}
                className={`h-12 rounded-2xl border text-sm font-medium ${knowsRelative === true ? "border-primary bg-primary/10 text-primary" : "border-border bg-card"}`}>
                Oui
              </button>
              <button onClick={() => { setKnowsRelative(false); setChosenRelative(null); }}
                className={`h-12 rounded-2xl border text-sm font-medium ${knowsRelative === false ? "border-primary bg-primary/10 text-primary" : "border-border bg-card"}`}>
                Non
              </button>
            </div>

            {knowsRelative === true && (
              <div className="mt-4 space-y-3">
                <div className="flex items-center gap-2 rounded-2xl border border-border bg-card px-3 py-2.5">
                  <Search className="h-4 w-4 text-muted-foreground" />
                  <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Nom de ton proche…"
                    className="flex-1 bg-transparent text-sm outline-none" />
                </div>
                <ul className="divide-y divide-border rounded-2xl border border-border bg-card">
                  {SAMPLE_RELATIVES
                    .filter((p) => !search || p.n.toLowerCase().includes(search.toLowerCase()))
                    .map((p) => (
                      <li key={p.id} onClick={() => setChosenRelative(p.id)}
                        className={`flex cursor-pointer items-center gap-3 p-3 ${chosenRelative === p.id ? "bg-primary/5" : ""}`}>
                        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-accent/30 font-display font-semibold">
                          {p.n.split(" ").map((s) => s[0]).slice(0, 2).join("")}
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium">{p.n}</p>
                          <p className="text-xs text-muted-foreground">{p.c} · {p.tree} membres</p>
                        </div>
                        {chosenRelative === p.id && <Check className="h-5 w-5 text-primary" />}
                      </li>
                    ))}
                  {SAMPLE_RELATIVES.filter((p) => !search || p.n.toLowerCase().includes(search.toLowerCase())).length === 0 && (
                    <li className="p-4 text-center text-xs text-muted-foreground">
                      Aucun résultat. Essaie un autre nom.
                    </li>
                  )}
                </ul>

                {chosenRelative && (
                  <div>
                    <p className="mb-1.5 text-xs text-muted-foreground">Quel est ton lien ?</p>
                    <div className="flex flex-wrap gap-2">
                      {["Père", "Mère", "Frère", "Sœur", "Oncle", "Tante", "Cousin·e"].map((r) => (
                        <button key={r} onClick={() => setRelation(r)}
                          className={`rounded-full px-3 py-1.5 text-sm ${relation === r ? "bg-primary text-primary-foreground" : "border border-border bg-card"}`}>
                          {r}
                        </button>
                      ))}
                    </div>
                    {relation && (
                      <div className="mt-3 flex items-start gap-2 rounded-xl border border-primary/20 bg-primary/5 p-3 text-[12px] text-foreground">
                        <Send className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                        <p>
                          Tu déclares <span className="font-semibold">{SAMPLE_RELATIVES.find((p) => p.id === chosenRelative)?.n}</span> comme ton/ta <span className="font-semibold">{relation.toLowerCase()}</span>.
                          Une demande de confirmation lui sera envoyée avant de fusionner vos arbres.
                        </p>
                      </div>
                    )}
                  </div>
                )}

                {liveRequest && (
                  <StatusCard request={liveRequest} />
                )}
              </div>
            )}

            {knowsRelative === false && (
              <p className="mt-3 rounded-2xl border border-dashed border-border bg-card p-3 text-xs text-muted-foreground">
                Pas de souci. Tu vas créer ton arbre en commençant par tes parents.
              </p>
            )}
          </Step>
        )}
      </div>

      <div className="sticky bottom-0 mt-4 border-t border-border bg-background/95 p-4 backdrop-blur">
        {step < total ? (
          <button onClick={next}
            className="flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-primary font-semibold text-primary-foreground active:scale-[0.99]">
            Continuer <ChevronRight className="h-4 w-4" />
          </button>
        ) : (
          <button
            onClick={finish}
            disabled={!step5Ready || sending || liveRequest?.status === "pending"}
            className="flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-primary font-semibold text-primary-foreground transition active:scale-[0.99] disabled:opacity-50"
          >
            {sending ? (
              <><Loader2 className="h-4 w-4 animate-spin" /> Envoi de la demande…</>
            ) : liveRequest?.status === "pending" ? (
              <><Clock className="h-4 w-4" /> En attente de confirmation…</>
            ) : liveRequest?.status === "accepted" ? (
              <><PartyPopper className="h-4 w-4" /> Ouvrir mon arbre fusionné</>
            ) : liveRequest?.status === "rejected" ? (
              <><ChevronRight className="h-4 w-4" /> Continuer sans lien</>
            ) : knowsRelative === true ? (
              <><Send className="h-4 w-4" /> Envoyer la demande</>
            ) : (
              <>Créer mon arbre <ChevronRight className="h-4 w-4" /></>
            )}
          </button>
        )}
      </div>
    </div>
  );
}

function StatusCard({ request }: { request: ReturnType<typeof useLinkRequest> }) {
  if (!request) return null;
  const tone =
    request.status === "pending"
      ? "border-accent/40 bg-accent/10 text-accent-foreground"
      : request.status === "accepted"
        ? "border-primary/30 bg-primary/10 text-foreground"
        : "border-destructive/30 bg-destructive/10 text-foreground";
  const Icon =
    request.status === "pending" ? Clock : request.status === "accepted" ? Check : X;
  return (
    <div className={`flex items-start gap-2 rounded-xl border p-3 text-[12px] ${tone}`}>
      <Icon className="mt-0.5 h-4 w-4 shrink-0" />
      <div className="flex-1">
        <p className="font-semibold">Demande {statusLabel(request.status).toLowerCase()}</p>
        <p className="mt-0.5 text-foreground/80">
          {request.status === "pending" && (
            <>En attente de la confirmation de {request.targetName}…</>
          )}
          {request.status === "accepted" && (
            <>{request.targetName} a confirmé le lien « {request.relation} ». Vos arbres seront fusionnés.</>
          )}
          {request.status === "rejected" && (
            <>{request.targetName} n'a pas confirmé. Tu peux continuer sans lien.</>
          )}
        </p>
      </div>
    </div>
  );
}

function Step({
  icon: Icon,
  title,
  subtitle,
  children,
}: {
  icon: typeof Phone;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-primary/10 text-primary">
          <Icon className="h-5 w-5" />
        </div>
        <div>
          <h1 className="font-display text-2xl text-foreground">{title}</h1>
          {subtitle && <p className="text-xs text-muted-foreground">{subtitle}</p>}
        </div>
      </div>
      <div className="space-y-3">{children}</div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="mb-1 block text-xs font-medium text-muted-foreground">{label}</label>
      {children}
    </div>
  );
}

function CountryAutocomplete({
  value,
  onChange,
  onRemove,
  placeholder,
}: {
  value: string;
  onChange: (v: string) => void;
  onRemove?: () => void;
  placeholder?: string;
}) {
  const [open, setOpen] = useState(false);
  const matches = value
    ? COUNTRIES.filter((c) => c.toLowerCase().includes(value.toLowerCase())).slice(0, 6)
    : [];
  return (
    <div className="relative">
      <div className="flex items-center gap-2 rounded-2xl border border-border bg-card px-3">
        <Search className="h-4 w-4 text-muted-foreground" />
        <input
          value={value}
          onChange={(e) => { onChange(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
          onBlur={() => setTimeout(() => setOpen(false), 150)}
          placeholder={placeholder}
          className="h-12 flex-1 bg-transparent text-sm outline-none"
        />
        {onRemove && (
          <button onClick={onRemove} className="text-muted-foreground hover:text-destructive">
            <X className="h-4 w-4" />
          </button>
        )}
      </div>
      {open && matches.length > 0 && (
        <ul className="absolute z-10 mt-1 max-h-56 w-full overflow-y-auto rounded-2xl border border-border bg-card shadow-lg">
          {matches.map((c) => (
            <li
              key={c}
              onMouseDown={() => { onChange(c); setOpen(false); }}
              className="cursor-pointer px-4 py-2 text-sm hover:bg-primary/5"
            >
              {c}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function FreeAutocomplete({
  value,
  onChange,
  suggestions,
  placeholder,
  icon,
  onRemove,
}: {
  value: string;
  onChange: (v: string) => void;
  suggestions: string[];
  placeholder?: string;
  icon?: React.ReactNode;
  onRemove?: () => void;
}) {
  const [open, setOpen] = useState(false);
  const last = value.split(",").pop()?.trim() ?? "";
  const matches = last
    ? suggestions.filter((s) => s.toLowerCase().startsWith(last.toLowerCase()) && s.toLowerCase() !== last.toLowerCase()).slice(0, 6)
    : [];
  const addSuggestion = (s: string) => {
    const parts = value.split(",").map((p) => p.trim()).filter(Boolean);
    parts[parts.length > 0 ? parts.length - 1 : 0] = s;
    onChange(parts.join(", "));
    setOpen(false);
  };
  return (
    <div className="relative">
      <div className="flex items-center gap-2 rounded-2xl border border-border bg-card px-3">
        {icon ?? <Search className="h-4 w-4 text-muted-foreground" />}
        <input
          value={value}
          onChange={(e) => { onChange(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
          onBlur={() => setTimeout(() => setOpen(false), 150)}
          placeholder={placeholder}
          className="h-12 flex-1 bg-transparent text-sm outline-none"
        />
        {onRemove && (
          <button onClick={onRemove} className="text-muted-foreground hover:text-destructive" aria-label="Retirer">
            <X className="h-4 w-4" />
          </button>
        )}
      </div>
      {open && matches.length > 0 && (
        <ul className="absolute z-10 mt-1 max-h-56 w-full overflow-y-auto rounded-2xl border border-border bg-card shadow-lg">
          {matches.map((s) => (
            <li
              key={s}
              onMouseDown={() => addSuggestion(s)}
              className="cursor-pointer px-4 py-2 text-sm hover:bg-primary/5"
            >
              {s}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
