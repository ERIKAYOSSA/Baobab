import { createFileRoute } from "@tanstack/react-router";
import { Link, useNavigate } from "@tanstack/react-router";
import { Fingerprint } from "lucide-react";
import { useState } from "react";
import baobabLogo from "@/assets/baobab-logo.png";

export const Route = createFileRoute("/")({
  component: Index,
});

function Index() {
  const navigate = useNavigate();
  const [planting, setPlanting] = useState(false);

  const handleStart = () => {
    if (planting) return;
    setPlanting(true);
    window.setTimeout(() => {
      navigate({ to: "/onboarding" });
    }, 1100);
  };

  return (
    <div className="relative min-h-dvh overflow-hidden bg-background bg-grain">
      <style>{`
        @keyframes baobab-press { 0% { transform: scale(1); opacity: 1; } 40% { transform: scale(0.78); opacity: 0.9; } 100% { transform: scale(0.6); opacity: 0; } }
        @keyframes baobab-ring { 0% { transform: scale(0.4); opacity: 0.7; } 100% { transform: scale(2.2); opacity: 0; } }
        @keyframes baobab-grow { 0% { stroke-dashoffset: 60; opacity: 0; } 30% { opacity: 1; } 100% { stroke-dashoffset: 0; opacity: 1; } }
        @keyframes baobab-leaf { 0% { transform: scale(0); opacity: 0; } 60% { transform: scale(1.2); opacity: 1; } 100% { transform: scale(1); opacity: 1; } }
        .anim-press { animation: baobab-press 0.5s ease-in forwards; }
        .anim-ring { animation: baobab-ring 0.7s ease-out forwards; }
        .anim-branch { stroke-dasharray: 60; stroke-dashoffset: 60; animation: baobab-grow 0.7s ease-out 0.35s forwards; }
        .anim-leaf { transform-origin: center; opacity: 0; animation: baobab-leaf 0.4s ease-out forwards; }
      `}</style>
      <div className="mx-auto flex min-h-dvh max-w-md flex-col px-6 pb-10 pt-16">
        <div className="flex flex-1 flex-col items-center justify-center text-center">
          <div className="mb-6 flex h-32 w-32 items-center justify-center rounded-full bg-primary/5 ring-8 ring-primary/5">
            <img
              src={baobabLogo}
              alt="Logo Baobab — arbre aux racines profondes et branches étendues, symbole d'union familiale"
              width={1024}
              height={1024}
              className="h-full w-full object-contain"
            />
          </div>
          <h1 className="font-display text-5xl leading-none text-foreground">Baobab</h1>
          <p className="mt-3 text-base text-muted-foreground">
            Ton arbre. Ta famille.<br />Ton héritage.
          </p>

          <div className="mt-10 grid w-full grid-cols-3 gap-2 text-xs">
            {[
              { t: "Arbre", d: "vivant" },
              { t: "Liens", d: "retrouvés" },
              { t: "Culture", d: "préservée" },
            ].map((f) => (
              <div key={f.t} className="rounded-2xl border border-border bg-card/60 p-3">
                <div className="font-display text-lg text-primary">{f.t}</div>
                <div className="text-muted-foreground">{f.d}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          <button
            type="button"
            onClick={handleStart}
            disabled={planting}
            aria-label="Commencer — planter mon arbre"
            className="relative flex h-14 w-full items-center justify-center gap-2 overflow-hidden rounded-2xl bg-primary text-primary-foreground shadow-lg shadow-primary/20 transition active:scale-[0.98]"
          >
            <span className="relative flex h-5 w-5 items-center justify-center">
              <Fingerprint className={`h-5 w-5 ${planting ? "anim-press" : ""}`} />
              {planting && (
                <span className="pointer-events-none absolute inset-0 rounded-full border-2 border-primary-foreground/70 anim-ring" />
              )}
              {planting && (
                <svg
                  viewBox="0 0 40 40"
                  className="pointer-events-none absolute left-1/2 top-1/2 h-10 w-10 -translate-x-1/2 -translate-y-1/2"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.6"
                  strokeLinecap="round"
                >
                  {/* roots */}
                  <path className="anim-branch" d="M20 22 C 17 26, 14 28, 10 30" />
                  <path className="anim-branch" style={{ animationDelay: "0.45s" }} d="M20 22 C 23 26, 26 28, 30 30" />
                  <path className="anim-branch" style={{ animationDelay: "0.55s" }} d="M20 22 L 20 32" />
                  {/* branches */}
                  <path className="anim-branch" style={{ animationDelay: "0.5s" }} d="M20 18 C 16 14, 13 12, 10 11" />
                  <path className="anim-branch" style={{ animationDelay: "0.6s" }} d="M20 18 C 24 14, 27 12, 30 11" />
                  {/* leaves */}
                  <circle className="anim-leaf" style={{ animationDelay: "0.9s" }} cx="10" cy="10" r="1.6" fill="currentColor" stroke="none" />
                  <circle className="anim-leaf" style={{ animationDelay: "1s" }} cx="30" cy="10" r="1.6" fill="currentColor" stroke="none" />
                  <circle className="anim-leaf" style={{ animationDelay: "1.05s" }} cx="20" cy="8" r="1.6" fill="currentColor" stroke="none" />
                </svg>
              )}
            </span>
            <span className="font-semibold">{planting ? "On plante…" : "Commencer"}</span>
          </button>
          <Link
            to="/tree"
            className="flex h-12 items-center justify-center rounded-2xl border border-border bg-card text-foreground active:scale-[0.98]"
          >
            Voir la démo
          </Link>
          <p className="pt-2 text-center text-xs text-muted-foreground">
            Disponible en Français · English · Kiswahili
          </p>
        </div>
      </div>
    </div>
  );
}
