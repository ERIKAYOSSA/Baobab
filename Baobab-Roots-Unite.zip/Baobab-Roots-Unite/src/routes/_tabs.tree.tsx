import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import {
  Plus,
  Sprout,
  Scroll,
  Settings2,
  Globe,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { FamilyTree } from "@/components/tree/FamilyTree";
import { SAMPLE_PEOPLE } from "@/components/tree/types";
import { useI18n } from "@/lib/i18n/I18nProvider";

export const Route = createFileRoute("/_tabs/tree")({
  component: TreeScreen,
});

function TreeScreen() {
  const [depth, setDepth] = useState(2);
  const [selectedId, setSelectedId] = useState("me");
  const selected = SAMPLE_PEOPLE.find((p) => p.id === selectedId) ?? SAMPLE_PEOPLE[0];
  const { t, locale } = useI18n();
  const year = selected.birth ? selected.birth.slice(-2) : "?";
  const yearStr = selected.death ? `${year} – ${selected.death.slice(-2)}` : year;
  const verifiedLabel = selected.verified ? t<string>("tree.verified") : t<string>("tree.notVerified");
  const meta = t<string>("common.profileMeta", { year: yearStr, verifiedLabel });

  return (
    <div className="flex flex-col">
      {/* Header (compact) */}
      <header className="sticky top-0 z-20 border-b border-border bg-background/90 px-4 pb-2 pt-3 backdrop-blur">
        <div className="flex items-center justify-between">
          <div className="flex items-baseline gap-2">
            <h1 className="font-display text-lg text-foreground">Famille Mensah</h1>
            <span className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
              {t("tree.eyebrow")}
            </span>
          </div>
          <button aria-label={t<string>("tree.settings")} className="flex h-8 w-8 items-center justify-center rounded-full bg-card text-foreground ring-1 ring-border">
            <Settings2 className="h-4 w-4" />
          </button>
        </div>
        <div className="mt-2 flex items-center gap-3">
          <span className="text-[11px] font-medium text-muted-foreground">N±{depth}</span>
          <input
            type="range"
            min={1}
            max={5}
            value={depth}
            onChange={(e) => setDepth(Number(e.target.value))}
            className="h-1 flex-1 cursor-pointer appearance-none rounded-full bg-muted accent-primary"
          />
          <span className="flex items-center gap-1 text-[11px] text-muted-foreground">
            <Globe className="h-3 w-3" /> {locale.toUpperCase()}
          </span>
        </div>
        <Legend />
      </header>

      {/* Tree canvas */}
      <div className="bg-grain pt-4">
        <FamilyTree
          people={SAMPLE_PEOPLE}
          selectedId={selectedId}
          onSelect={setSelectedId}
          meId="me"
          depth={depth}
        />
      </div>

      {/* Selected card */}
      <div className="sticky bottom-20 z-10 mx-3 mt-2 rounded-3xl border border-border bg-card p-4 shadow-[0_8px_24px_-12px_oklch(0.42_0.09_145/0.3)]">
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 font-display text-base font-semibold text-primary">
            {selected.name.split(" ").map((s) => s[0]).slice(0, 2).join("")}
          </div>
          <div className="flex-1">
            <p className="font-display text-base text-foreground">{selected.name}</p>
            <p className="text-xs text-muted-foreground">{meta}</p>
          </div>
        </div>
        <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
          <ActionBtn icon={Sprout} label={t<string>("tree.enrichTree")} />
          <ActionBtn icon={Scroll} label={t<string>("tree.legacy")} />
        </div>
      </div>

      {/* FAB (compact) */}
      <button
        className="fixed bottom-28 right-5 z-30 flex h-11 w-11 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg shadow-primary/30 active:scale-95"
        aria-label={t<string>("tree.addPerson")}
      >
        <Plus className="h-5 w-5" />
      </button>
    </div>
  );
}

function Legend() {
  const { t } = useI18n();
  return (
    <div className="mt-3 flex flex-wrap gap-x-3 gap-y-1 text-[10px] text-muted-foreground">
      <Item dot="bg-vital-alive">{t("tree.legendAlive")}</Item>
      <Item dot="bg-vital-deceased">{t("tree.legendDeceased")}</Item>
      <Item dot="bg-vital-unknown">{t("tree.legendUnknown")}</Item>
    </div>
  );
}

function Item({ dot, children }: { dot: string; children: React.ReactNode }) {
  return (
    <span className="flex items-center gap-1">
      <span className={`h-2 w-2 rounded-full ${dot}`} /> {children}
    </span>
  );
}

function ActionBtn({ icon: Icon, label }: { icon: LucideIcon; label: string }) {
  return (
    <button className="flex items-center justify-center gap-2 rounded-xl border border-border bg-background px-3 py-3 font-medium text-foreground active:scale-[0.98]">
      <Icon className="h-4 w-4 text-primary" />
      {label}
    </button>
  );
}