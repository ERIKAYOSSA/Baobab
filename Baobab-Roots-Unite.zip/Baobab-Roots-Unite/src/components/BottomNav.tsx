import { Link, useLocation } from "@tanstack/react-router";
import { TreePine, Compass, Bell, User } from "lucide-react";
import { useI18n } from "@/lib/i18n/I18nProvider";

type Tab = {
  to: "/tree" | "/discover" | "/notifications" | "/me";
  labelKey: "nav.tree" | "nav.discover" | "nav.notifications" | "nav.me";
  icon: typeof TreePine;
  badge?: number;
};

const tabs: Tab[] = [
  { to: "/tree", labelKey: "nav.tree", icon: TreePine },
  { to: "/discover", labelKey: "nav.discover", icon: Compass },
  { to: "/notifications", labelKey: "nav.notifications", icon: Bell, badge: 3 },
  { to: "/me", labelKey: "nav.me", icon: User },
];

export function BottomNav() {
  const { pathname } = useLocation();
  const { t } = useI18n();
  return (
    <nav className="pointer-events-auto fixed inset-x-0 bottom-0 z-40 mx-auto max-w-md px-3 pb-3">
      <div className="flex items-stretch justify-between rounded-3xl border border-border bg-card/95 p-1.5 shadow-[0_8px_32px_-8px_oklch(0.42_0.09_145/0.25)] backdrop-blur">
        {tabs.map((tab) => {
          const active = pathname.startsWith(tab.to);
          const Icon = tab.icon;
          return (
            <Link
              key={tab.to}
              to={tab.to}
              className={`group relative flex flex-1 flex-col items-center gap-0.5 rounded-2xl py-2 text-[11px] font-medium transition ${
                active
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <div className="relative">
                <Icon className="h-5 w-5" strokeWidth={active ? 2.2 : 1.8} />
                {tab.badge ? (
                  <span className="absolute -right-2 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-accent px-1 text-[10px] font-bold text-accent-foreground">
                    {tab.badge}
                  </span>
                ) : null}
              </div>
              <span>{t(tab.labelKey)}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}