export type Person = {
  id: string;
  name: string;
  birth?: string;
  death?: string;
  status: "alive" | "deceased" | "unknown";
  verified: boolean;
  gender: "f" | "m";
  ethnicity?: string;
  title?: "chief" | "elder" | "notable";
  parentIds?: string[];
  spouseIds?: string[];
  motherId?: string;
  fatherId?: string;
};

export const SAMPLE_PEOPLE: Person[] = [
  { id: "gp1", name: "Mzee Kofi", birth: "1928", death: "2001", status: "deceased", verified: true, gender: "m", title: "chief" },
  { id: "gp2", name: "Ama Serwaa", birth: "1932", death: "2018", status: "deceased", verified: true, gender: "f", spouseIds: ["gp1"], title: "elder" },
  { id: "gp3", name: "Baba Yao", birth: "1925", death: "1999", status: "deceased", verified: false, gender: "m" },
  { id: "gp4", name: "Akua Mansa", birth: "1930", status: "alive", verified: true, gender: "f", spouseIds: ["gp3"], title: "elder" },
  { id: "p1", name: "Kwame Mensah", birth: "1958", status: "alive", verified: true, gender: "m", fatherId: "gp1", motherId: "gp2", spouseIds: ["p2", "p2b"] },
  { id: "p2", name: "Adjoa Mensah", birth: "1962", status: "alive", verified: true, gender: "f", fatherId: "gp3", motherId: "gp4", spouseIds: ["p1"] },
  { id: "p2b", name: "Efua N.", birth: "1968", status: "alive", verified: false, gender: "f", spouseIds: ["p1"] },
  { id: "me", name: "Toi (Kojo)", birth: "1992", status: "alive", verified: true, gender: "m", fatherId: "p1", motherId: "p2" },
  { id: "sib1", name: "Ama", birth: "1989", status: "alive", verified: true, gender: "f", fatherId: "p1", motherId: "p2" },
  { id: "sib2", name: "Yaw", birth: "1996", status: "alive", verified: false, gender: "m", fatherId: "p1", motherId: "p2" },
  { id: "sib3", name: "Esi", birth: "2002", status: "unknown", verified: false, gender: "f", fatherId: "p1", motherId: "p2b" },
  { id: "ch1", name: "Akosua", birth: "2020", status: "alive", verified: true, gender: "f", fatherId: "me" },
];