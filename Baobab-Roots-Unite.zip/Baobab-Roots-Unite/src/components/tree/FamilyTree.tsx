import { useMemo } from "react";
import { Lock, Crown, Star, BadgeCheck, Flower2 } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import type { Person } from "./types";
import { useI18n } from "@/lib/i18n/I18nProvider";

type Props = {
  people: Person[];
  selectedId: string;
  onSelect: (id: string) => void;
  meId: string;
  depth: number; // 1..5
};

export function FamilyTree({ people, selectedId, onSelect, meId, depth }: Props) {
  const { t } = useI18n();
  const byId = useMemo(() => Object.fromEntries(people.map((p) => [p.id, p])), [people]);

  const me = byId[meId];
  if (!me) return null;

  // Build generations: ancestors above, descendants below
  const ancestorsGen1 = [me.fatherId, me.motherId].filter(Boolean).map((id) => byId[id!]);
  const ancestorsGen2 = ancestorsGen1.flatMap((p) =>
    p ? [p.fatherId, p.motherId].filter(Boolean).map((id) => byId[id!]) : []
  );
  const siblings = people.filter(
    (p) => p.id !== meId && (p.fatherId === me.fatherId || p.motherId === me.motherId) && (p.fatherId || p.motherId)
  );
  const meCouple = (me.spouseIds ?? []).map((id) => byId[id]).filter(Boolean);
  const children = people.filter((p) => p.fatherId === meId || p.motherId === meId);

  const showAncestors2 = depth >= 2;
  const showAncestors1 = depth >= 1;
  const showChildren = depth >= 1;

  return (
    <div className="flex flex-col items-stretch gap-6 pb-4">
      {showAncestors2 && ancestorsGen2.length > 0 && (
        <Generation label="Grands-parents">
          {ancestorsGen2.map((p) => (
            <Node key={p.id} p={p} selected={selectedId === p.id} onSelect={onSelect} small />
          ))}
        </Generation>
      )}
      {showAncestors2 && ancestorsGen2.length > 0 && <Connector label={t<string>("tree.relParent")} />}
      {showAncestors1 && ancestorsGen1.length > 0 && (
        <Generation label="Parents">
          <CoupleRow people={ancestorsGen1} selectedId={selectedId} onSelect={onSelect} />
        </Generation>
      )}
      {showAncestors1 && ancestorsGen1.length > 0 && <Connector label={t<string>("tree.relParent")} />}

      <Generation label="Toi & fratrie" tone="primary">
        {siblings.map((p) => (
          <Node key={p.id} p={p} selected={selectedId === p.id} onSelect={onSelect} small />
        ))}
        <Node p={me} selected={selectedId === meId} onSelect={onSelect} highlight />
        {meCouple.map((sp) => (
          <div key={sp.id} className="flex shrink-0 snap-center items-center gap-1">
            <RelTag>{t<string>("tree.relSpouse")}</RelTag>
            <Node p={sp} selected={selectedId === sp.id} onSelect={onSelect} small />
          </div>
        ))}
      </Generation>

      {showChildren && children.length > 0 && <Connector label={t<string>("tree.relChild")} />}
      {showChildren && children.length > 0 && (
        <Generation label="Enfants">
          {children.map((p) => (
            <Node key={p.id} p={p} selected={selectedId === p.id} onSelect={onSelect} small />
          ))}
          <AddNode label="Ajouter" onClick={() => onSelect("__add__")} />
        </Generation>
      )}
    </div>
  );
}

function Generation({
  children,
  label,
  tone = "muted",
}: {
  children: React.ReactNode;
  label: string;
  tone?: "muted" | "primary";
}) {
  return (
    <div className="flex flex-col items-center gap-2">
      <span
        className={`rounded-full px-2.5 py-0.5 text-[10px] font-medium uppercase tracking-wider ${
          tone === "primary" ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"
        }`}
      >
        {label}
      </span>
      <div className="scrollbar-hide w-full snap-x overflow-x-auto overflow-y-hidden scroll-smooth">
        <div className="mx-auto flex w-max items-end gap-3 px-6">
          {children}
        </div>
      </div>
    </div>
  );
}

function CoupleRow({
  people,
  selectedId,
  onSelect,
}: {
  people: Person[];
  selectedId: string;
  onSelect: (id: string) => void;
}) {
  const { t } = useI18n();
  return (
    <div className="flex shrink-0 snap-center items-center gap-1.5">
      {people.map((p, i) => (
        <div key={p.id} className="flex items-center gap-1.5">
          {i > 0 && <RelTag>{t<string>("tree.relSpouse")}</RelTag>}
          <Node p={p} selected={selectedId === p.id} onSelect={onSelect} />
        </div>
      ))}
    </div>
  );
}

function Connector({ label }: { label?: string }) {
  return (
    <div className="relative flex h-9 items-center justify-center" aria-hidden>
      <div className="h-full w-px bg-border" />
      {label && (
        <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 whitespace-nowrap rounded-full border border-border bg-background px-2 py-0.5 text-[9px] font-medium uppercase tracking-wider text-muted-foreground shadow-sm">
          {label}
        </span>
      )}
    </div>
  );
}

function RelTag({ children }: { children: React.ReactNode }) {
  return (
    <span className="whitespace-nowrap rounded-full border border-border bg-background px-1.5 py-0.5 text-[8px] font-medium uppercase tracking-wide text-muted-foreground shadow-sm">
      {children}
    </span>
  );
}

function getBadge(p: Person): { Icon: LucideIcon; tone: string } | null {
  if (p.title === "chief") return { Icon: Crown, tone: "bg-gold text-gold-foreground" };
  if (p.title === "elder") return { Icon: Star, tone: "bg-earth text-earth-foreground" };
  if (p.title === "notable") return { Icon: Star, tone: "bg-accent text-accent-foreground" };
  if (p.status === "deceased" || p.death) return { Icon: Flower2, tone: "bg-muted text-muted-foreground" };
  if (p.verified) return { Icon: BadgeCheck, tone: "bg-primary text-primary-foreground" };
  return null;
}

function Node({
  p,
  selected,
  onSelect,
  small,
  highlight,
}: {
  p: Person;
  selected: boolean;
  onSelect: (id: string) => void;
  small?: boolean;
  highlight?: boolean;
}) {
  const ring =
    p.status === "alive"
      ? "ring-vital-alive"
      : p.status === "deceased"
        ? "ring-vital-deceased"
        : "ring-vital-unknown";
  const dot =
    p.status === "alive"
      ? "bg-vital-alive"
      : p.status === "deceased"
        ? "bg-vital-deceased"
        : "bg-vital-unknown";
  const size = small ? "h-12 w-12 text-[11px]" : "h-16 w-16 text-sm";
  const initials = p.name.split(" ").map((s) => s[0]).slice(0, 2).join("");
  const isDeceased = p.status === "deceased" || Boolean(p.death);
  const badge = getBadge(p);
  return (
    <button
      onClick={() => onSelect(p.id)}
      className="group flex shrink-0 snap-center flex-col items-center gap-1"
    >
      <div className="relative">
        <div
          className={`flex ${size} items-center justify-center rounded-full font-display font-semibold ring-4 transition ${ring} ${
            isDeceased ? "grayscale" : ""
          } ${
            selected ? "scale-110 ring-offset-2 ring-offset-background" : ""
          } ${highlight ? "bg-primary text-primary-foreground" : "bg-card text-foreground"}`}
        >
          {initials}
        </div>
        {badge && (
          <span
            className={`absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full border-2 border-background shadow-sm ${badge.tone}`}
          >
            <badge.Icon className="h-2.5 w-2.5" />
          </span>
        )}
        <span
          className={`absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-background ${dot}`}
          aria-label={p.status}
        />
        {!p.verified && (
          <span className="absolute -top-1 -left-1 flex h-4 w-4 items-center justify-center rounded-full border border-border bg-card text-muted-foreground">
            <Lock className="h-2.5 w-2.5" />
          </span>
        )}
      </div>
      <span className="max-w-[72px] truncate text-[11px] font-medium text-foreground">{p.name}</span>
      {(p.birth || p.death) && (
        <span className="text-[10px] text-muted-foreground">
          {p.birth ?? "?"}
          {p.death ? `–${p.death}` : ""}
        </span>
      )}
    </button>
  );
}

function AddNode({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex shrink-0 snap-center flex-col items-center gap-1 opacity-80 transition hover:opacity-100"
    >
      <div className="flex h-12 w-12 items-center justify-center rounded-full border-2 border-dashed border-border bg-card text-muted-foreground">
        +
      </div>
      <span className="text-[10px] text-muted-foreground">{label}</span>
    </button>
  );
}