import neo4j, { Driver } from 'neo4j-driver';
import dotenv from 'dotenv';

dotenv.config();

const uri = process.env.NEO4J_URI || 'bolt://localhost:7687';
const user = process.env.NEO4J_USER || 'neo4j';
const password = process.env.NEO4J_PASSWORD || 'password';

export const driver: Driver = neo4j.driver(
  uri,
  neo4j.auth.basic(user, password)
);

export async function verifyConnection(): Promise<void> {
  try {
    await driver.verifyConnectivity();
    console.log('✅ Connexion Neo4j établie avec succès');
  } catch (error) {
    console.error('❌ Échec de la connexion à Neo4j:', error);
    throw error;
  }
}

export async function closeDriver(): Promise<void> {
  await driver.close();
}

export default driver;