import express, { Request, Response } from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { verifyConnection, closeDriver } from './db/neo4j';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

app.get('/health', (_req: Request, res: Response) => {
  res.json({ status: 'ok', service: 'baobab-api' });
});

// TODO: monter les routes ici (ex: app.use('/api/users', usersRouter))

async function start() {
  try {
    await verifyConnection();
    app.listen(PORT, () => {
      console.log(`🚀 Serveur Baobab API démarré sur http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Erreur au démarrage du serveur:', error);
    process.exit(1);
  }
}

process.on('SIGINT', async () => {
  console.log('\nArrêt du serveur...');
  await closeDriver();
  process.exit(0);
});

start();